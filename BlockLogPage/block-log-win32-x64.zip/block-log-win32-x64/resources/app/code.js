/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 4);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = global;


const OBJ = {
    programContent: [],
    variablesContent: {},
};

function global() {
    return OBJ;
}


/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




const BOX = "box";
const STR = "str";
const STR_SECOND = "str_second";

class DragControl {
    static inBox(boxX, boxY, boxW, boxH, xx, yy) {
        if(boxX <= xx && xx <= boxX + boxW) {
            if(boxY <= yy && yy <= boxY + boxH) {
                return true;
            }
        }
        return false;
    }

    static hideBoxes() {
        document.getElementById("contentOfBlockBox").hidden = true;
        document.getElementById("contentOfVetvlenieBox").hidden = true;
        document.getElementById("contentOfPrintingBox").hidden = true;
        document.getElementById("contentOfNoContentBox").hidden = true;
        document.getElementById("readBoxCCCCCC").hidden = true;
    }

    setElement(element) {
        this.selectedToChange = null;
        const arr = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent;
        for(let i = 0; i < arr.length; i++) {
            const b = arr[i];
            b.selectValue = null;
        }
        this.selectedToChange = element;
    }

    callWorkingPropsOfBlock() {
        if(Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().propsManager) {
            if(this.selectedToChange.basic === true) {
                Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().propsManager.workProps(this.selectedToChange);
                document.getElementById("contentOfBlockBox").hidden = false;
            } else if(this.selectedToChange.vetvlenie === true) {
                Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().propsManager.workPropsOfVetvlenie(this.selectedToChange);
                document.getElementById("contentOfVetvlenieBox").hidden = false;
            } else if(this.selectedToChange.printingVars === true) {
                Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().propsManager.workPropsOfPrintingElements(this.selectedToChange);
                document.getElementById("contentOfPrintingBox").hidden = false;
            } else if(this.selectedToChange.readingDataBox === true) {
                Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().propsManager.workPropsWithInputDataBox(this.selectedToChange);
                document.getElementById("readBoxCCCCCC").hidden = false;
            } else {
                document.getElementById("contentOfNoContentBox").hidden = false;
            }
        }
    }

    setSelectedToChange(element) {
        this.setElement(element);
        if(this.selectedToChange) {
            this.selectedToChange.selectValue = true;
            DragControl.hideBoxes();
            this.callWorkingPropsOfBlock();
        }
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    }

    initMouseUpAction() {
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.mouseUpAction = (xxx, yyy) => {
            this.selected = null;
            this.deltaX = 0;
            this.deltaY = 0;
            this.type = null;
        };
    }

    controlFirstStr(arr, dx, dy, xxx, yyy) {
        for(let i = arr.length - 1; i >= 0; i--) {
            const b = arr[i];
            if (DragControl.inBox(b.strFinishX + dx - 10, b.strFinishY + dy - 10, 20, 20, xxx, yyy) === true) {
                this.selected = b;
                this.deltaX = xxx - b.strFinishX;
                this.deltaY = yyy - b.strFinishY;
                this.type = STR;
                return true;
            }
        }
        return false;
    }

    controlSecondStr(arr, dx, dy, xxx, yyy) {
        for(let i = arr.length - 1; i >= 0; i--) {
            const b = arr[i];
            if (b.vetvlenie) {
                if (DragControl.inBox(b.strFinishXsecond + dx - 10, b.strFinishYsecond + dy - 10, 20, 20, xxx, yyy) === true) {
                    this.selected = b;
                    this.deltaX = xxx - b.strFinishXsecond;
                    this.deltaY = yyy - b.strFinishYsecond;
                    this.type = STR_SECOND;
                    return true;
                }
            }
        }
        return false;
    }

    controlBox(arr, dx, dy, xxx, yyy) {
        for(let i = arr.length - 1; i >= 0; i--) {
            const b = arr[i];
            if(DragControl.inBox(b.x + dx, b.y + dy, b.w, b.h, xxx, yyy) === true) {
                this.selected = b;
                this.setSelectedToChange(this.selected);
                this.deltaX = xxx - b.x;
                this.deltaY = yyy - b.y;
                this.type = BOX;
                return true;
            }
        }
        return false;
    }

    initMouseDownAction() {
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.mouseDownAction = (xxx, yyy) => {
            const dx = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dx;
            const dy = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dy;
            const arr = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent;
            if(!this.controlFirstStr(arr, dx, dy, xxx, yyy)) {
                if(!this.controlSecondStr(arr, dx, dy, xxx, yyy)) {
                    if(!this.controlBox(arr, dx, dy, xxx, yyy)) {
                        console.log("No hit");
                    }
                }
            }
        };
    }

    initFields() {
        this.selectedToChange = null;
        this.setSelectedToChange(null);
        this.selected = null;
        this.deltaX = 0;
        this.deltaY = 0;
        this.type = null;
    }

    workIfConnectElementsTrue(xxx, yyy) {
        if(Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().connectElements === true) {
            this.selected.strFinishX = xxx - this.deltaX + this.selected.w / 2;
            this.selected.strFinishY = yyy - this.deltaY + this.selected.h + 100;
            if(this.selected.vetvlenie) {
                this.selected.strFinishX = xxx - this.deltaX + this.selected.w / 2 - 50;
                this.selected.strFinishY = yyy - this.deltaY + this.selected.h + 100;
                this.selected.strFinishXsecond = xxx - this.deltaX + this.selected.w / 2 + 50;
                this.selected.strFinishYsecond = yyy - this.deltaY + this.selected.h + 100;
            }
        }
    }

    controlStrFirst(xxx, yyy) {
        this.selected.strFinishX = xxx - this.deltaX;
        this.selected.strFinishY = yyy - this.deltaY;
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    }

    controlStrSecond(xxx, yyy) {
        this.selected.strFinishXsecond = xxx - this.deltaX;
        this.selected.strFinishYsecond = yyy - this.deltaY;
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    }

    initMouseMoveAction() {
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.mouseMoveAction = (xxx, yyy) => {
            if(this.selected !== null) {
                if(this.type === BOX) {
                    this.selected.x = xxx - this.deltaX;
                    this.selected.y = yyy - this.deltaY;
                    this.workIfConnectElementsTrue(xxx, yyy);
                    Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
                } else if(this.type === STR) {
                    this.controlStrFirst(xxx, yyy);
                } else if(this.type === STR_SECOND) {
                    this.controlStrSecond(xxx, yyy);
                }
            }
        };
    }

    addEventToDeletingBtn() {
        const xxxValue = -999999999;
        document.getElementById("deleteBlockBtn").onclick = () => {
            if(this.selectedToChange) {
                if(this.selectedToChange.content !== "Start") {
                    this.selectedToChange.x = xxxValue;
                    this.selectedToChange.y = xxxValue;
                    this.selectedToChange.strFinishX = xxxValue;
                    this.selectedToChange.strFinishY = xxxValue;
                    this.selectedToChange.strFinishXsecond = xxxValue;
                    this.selectedToChange.strFinishYsecond = xxxValue;
                }
            }
            // no content
            DragControl.hideBoxes();
            document.getElementById("contentOfNoContentBox").hidden = false;
            // redraw canvas
            Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.clearFon();
            Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
        }
    }

    constructor() {
        console.log("Create DragControl");
        // init
        this.initFields();
        // mouse events
        this.initMouseDownAction();
        this.initMouseUpAction();
        this.initMouseMoveAction();
        // delete btn event
        this.addEventToDeletingBtn();
    }
}
/* harmony export (immutable) */ __webpack_exports__["a"] = DragControl;



/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("electron");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("fs");

/***/ }),
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__CanvasControl_CanvasManager__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__GlobalObjStore_global__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__DragManage_DragControl__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__BlocksPropsControl_PropsManager__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__Scroll_leftMenuScroll__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__Scroll_canvasScroll__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__Scroll_buttonsScroll__ = __webpack_require__(9);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__CreatingBlocks_creatingIfElseBlock__ = __webpack_require__(10);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__CreatingBlocks_creatingConnectBlock__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__CreatingBlocks_creatingPrintingBlock__ = __webpack_require__(12);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__CreatingBlocks_creatingBasicBlock__ = __webpack_require__(13);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__CreatingBlocks_createStartB__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__BlockStrConnect_connectBtnControl__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__HideShowConsole_hideShowConsoleEvent__ = __webpack_require__(16);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__RunProgram_runProgramEvent__ = __webpack_require__(17);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__JqLibScripts_jqueryManager__ = __webpack_require__(19);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__RunProgram_InitVarsControl__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__ScaleControl_controlScale__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__FilesControl_saveProjectFile__ = __webpack_require__(23);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_19__FilesControl_loadProjectFile__ = __webpack_require__(24);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_20__CreatingBlocks_createReadBlock__ = __webpack_require__(25);
























window.onload = function() {
    // main objects creating
    Object(__WEBPACK_IMPORTED_MODULE_1__GlobalObjStore_global__["a" /* default */])().canvasManager = new __WEBPACK_IMPORTED_MODULE_0__CanvasControl_CanvasManager__["a" /* default */]();
    Object(__WEBPACK_IMPORTED_MODULE_1__GlobalObjStore_global__["a" /* default */])().dragControl = new __WEBPACK_IMPORTED_MODULE_2__DragManage_DragControl__["a" /* default */]();
    Object(__WEBPACK_IMPORTED_MODULE_1__GlobalObjStore_global__["a" /* default */])().propsManager = new __WEBPACK_IMPORTED_MODULE_3__BlocksPropsControl_PropsManager__["a" /* default */]();
    Object(__WEBPACK_IMPORTED_MODULE_1__GlobalObjStore_global__["a" /* default */])().initVarsControl = new __WEBPACK_IMPORTED_MODULE_16__RunProgram_InitVarsControl__["a" /* default */]();

    // control scroll events
    Object(__WEBPACK_IMPORTED_MODULE_4__Scroll_leftMenuScroll__["a" /* default */])();
    Object(__WEBPACK_IMPORTED_MODULE_5__Scroll_canvasScroll__["a" /* default */])();
    Object(__WEBPACK_IMPORTED_MODULE_6__Scroll_buttonsScroll__["a" /* default */])();

    // creating boxes events
    Object(__WEBPACK_IMPORTED_MODULE_7__CreatingBlocks_creatingIfElseBlock__["a" /* default */])();
    Object(__WEBPACK_IMPORTED_MODULE_8__CreatingBlocks_creatingConnectBlock__["a" /* default */])();
    Object(__WEBPACK_IMPORTED_MODULE_9__CreatingBlocks_creatingPrintingBlock__["a" /* default */])();
    Object(__WEBPACK_IMPORTED_MODULE_10__CreatingBlocks_creatingBasicBlock__["a" /* default */])();
    Object(__WEBPACK_IMPORTED_MODULE_20__CreatingBlocks_createReadBlock__["a" /* default */])();

    // create once starting box
    Object(__WEBPACK_IMPORTED_MODULE_11__CreatingBlocks_createStartB__["a" /* default */])();

    // add event of connecting block and str while moving
    Object(__WEBPACK_IMPORTED_MODULE_12__BlockStrConnect_connectBtnControl__["a" /* default */])();

    // add hide and show console event on btn
    Object(__WEBPACK_IMPORTED_MODULE_13__HideShowConsole_hideShowConsoleEvent__["a" /* default */])();

    // add run program btn event
    Object(__WEBPACK_IMPORTED_MODULE_14__RunProgram_runProgramEvent__["a" /* default */])();

    // manage jquery
    Object(__WEBPACK_IMPORTED_MODULE_15__JqLibScripts_jqueryManager__["a" /* default */])();

    // scale of window
    Object(__WEBPACK_IMPORTED_MODULE_17__ScaleControl_controlScale__["a" /* default */])();

    // saving files control
    Object(__WEBPACK_IMPORTED_MODULE_18__FilesControl_saveProjectFile__["a" /* default */])();

    // loading files control
    Object(__WEBPACK_IMPORTED_MODULE_19__FilesControl_loadProjectFile__["a" /* default */])();
};



/***/ }),
/* 5 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




const BACKGROUND_COLOR = '#CCCCCC';
const WWW = 2500;
const HHH = 2500;

class CanvasManager {
    initDeltaXY() {
        this.dx = 0;
        this.dy = 0;
    }

    initCanvasAndHolst() {
        this.can = document.getElementById('can');
        this.holst = this.can.getContext('2d');
    }

    createEventsFields() {
        this.mouseDownAction = function () {};
        this.mouseUpAction = function () {};
        this.mouseMoveAction = function () {};
    }

    initMouseDownEvent() {
        this.can.onmousedown = (event) => {
            const xMouse = parseInt(event.offsetX);
            const yMouse = parseInt(event.offsetY);
            this.mouseDownAction(xMouse, yMouse);
        };
    }

    initMouseUpEvent() {
        this.can.onmouseup = (event) => {
            const xMouse = parseInt(event.offsetX);
            const yMouse = parseInt(event.offsetY);
            this.mouseUpAction(xMouse, yMouse);
        };
    }

    initMouseMoveEvent() {
        this.can.onmousemove = (event) => {
            const xMouse = parseInt(event.offsetX);
            const yMouse = parseInt(event.offsetY);
            this.mouseMoveAction(xMouse, yMouse);
        };
    }

    loadImage() {
        this.myImg = new Image();
        this.myImg.src = ("paper.jpg");
        this.myImg.onload = () => {
            console.log("-- Load paper image OK --");
            // draw empty fon
            this.clearFon();
            // print content
            this.printAllBoxes();
        }
    }

    constructor() {
        console.log("Create CanvasManager");
        // init
        this.initDeltaXY();
        this.initCanvasAndHolst();
        this.createEventsFields();
        // init mouse events fields
        this.initMouseDownEvent();
        this.initMouseUpEvent();
        this.initMouseMoveEvent();
        // load image
        this.loadImage();
        // draw empty fon
        this.clearFon();
        // init draw line mode
        this.allowDrawLine = true;
    }

    drawImage() {
        const deltaSize = 300;
        try {
            for(let i = 0; i < 11; i++) {
                for(let j = 0; j < 11; j++) {
                    this.holst.drawImage(this.myImg, i * deltaSize, j * deltaSize, deltaSize, deltaSize);
                }
            }
        } catch (err) {
            // err
        }
    }

    clearFon() {
        this.holst.fillStyle = BACKGROUND_COLOR;
        const startValue = 0;
        // clear content
        this.holst.clearRect(startValue, startValue, WWW, HHH);
        // draw background
        this.holst.fillRect(startValue, startValue, WWW, HHH);
        // draw image
        this.drawImage();
    }

    setBoxBorderColor(flag) {
        if(flag) {
            this.setStrokeColor('#ff211c');
        } else {
            this.setStrokeColor('#0000FF');
        }
    }

    renderText(x, y, content) {
        this.holst.fillStyle = '#000000';
        this.holst.font = "15px Arial";
        this.holst.fillText(content,x + 10,y + 30);
    }

    drawSquareForBox(x, y, w, h) {
        this.holst.fillStyle = '#FFFFFF';
        this.holst.fillRect(x, y, w, h);
        this.holst.lineWidth = 1;
        this.holst.fillStyle = '#000000';
        this.holst.strokeRect(x, y, w, h);
    }

    drawBox(x, y, w, h, content, flag) {
        this.setBoxBorderColor(flag);
        this.drawSquareForBox(x, y, w, h);
        this.renderText(x, y, content);
    }

    drawStr(x1, y1, x2, y2, color) {
        this.setStrokeColor(color);
        this.holst.lineWidth = 3;
        this.drawSimpleLine(x1, y1, x2, y2);
        this.drawLittleKv(x2, y2);
    }

    setStrokeColor(color) {
        if(!color) {
            this.holst.strokeStyle = '#000000';
        } else {
            this.holst.strokeStyle = color;
        }
    }

    drawSimpleLine(x1, y1, x2, y2) {
        if(this.allowDrawLine === true) {
            this.holst.beginPath();
            this.holst.moveTo(x1, y1);
            this.holst.lineTo(x2, y2);
            this.holst.closePath();
            this.holst.stroke();
        }
    }

    drawLittleKv(x2, y2) {
        // little square
        this.holst.fillStyle = '#c39ecc';
        this.holst.strokeStyle = '#0000FF';
        this.holst.fillRect(x2 - 10, y2 - 10, 20, 20);
        this.holst.strokeRect(x2 - 10, y2 - 10, 20, 20);
    }

    printAllWithDrawLine(arr, yesColor, noColor) {
        for(let i = 0; i < arr.length; i++) {
            const box = arr[i];
            const strStartX = box.x + this.dx + box.w / 2;
            const strStartY = box.y + this.dy + box.h;
            if(!box.vetvlenie) {
                this.drawStr(strStartX, strStartY, box.strFinishX + this.dx, box.strFinishY + this.dy);
            } else {
                this.drawStr(strStartX, strStartY, box.strFinishX + this.dx, box.strFinishY + this.dy, yesColor);
                this.drawStr(strStartX, strStartY, box.strFinishXsecond + this.dx, box.strFinishYsecond + this.dy, noColor);
            }
            if(!box.selectValue) {
                this.drawBox(box.x + this.dx, box.y + this.dy, box.w, box.h, box.content);
            } else {
                this.drawBox(box.x + this.dx, box.y + this.dy, box.w, box.h, box.content, true);
            }
        }
    }

    printAllWithNotDrawLine(arr, yesColor, noColor) {
        for(let i = 0; i < arr.length; i++) {
            const box = arr[i];
            const strStartX = box.x + this.dx + box.w / 2;
            const strStartY = box.y + this.dy + box.h;
            if(!box.vetvlenie) {
                this.drawStr(strStartX, strStartY, box.strFinishX + this.dx, box.strFinishY + this.dy);
            } else {
                this.drawStr(strStartX, strStartY, box.strFinishX + this.dx, box.strFinishY + this.dy, yesColor);
                this.drawStr(strStartX, strStartY, box.strFinishXsecond + this.dx, box.strFinishYsecond + this.dy, noColor);
            }
        }
    }

    printAllBoxes() {
        // clear content
        this.clearFon();
        // get array of boxes
        const arr = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent;
        // init colors
        const yesColor = "#00FF00";
        const noColor = "#FF0000";
        // init draw line mode
        this.allowDrawLine = true;
        // print with YES mode
        this.printAllWithDrawLine(arr, yesColor, noColor);
        // init draw line mode
        this.allowDrawLine = false;
        // print with NO mode
        this.printAllWithNotDrawLine(arr, yesColor, noColor);
    }
}
/* harmony export (immutable) */ __webpack_exports__["a"] = CanvasManager;




/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




function getId(idString) {
    return document.getElementById(idString);
}

class PropsManager {
    initDomElements() {
        this.resultField = getId("t1");
        this.partA = getId("t2");
        this.partB = getId("t3");
        this.submitBtn = getId("b1");
    }

    controlBasicBlockAction() {
        const colorString = "rgb(26, 142, 27)";
        if(getId("v1").style.background === colorString) this.element.action.tAction = "+";
        if(getId("v2").style.background === colorString) this.element.action.tAction = "-";
        if(getId("v3").style.background === colorString) this.element.action.tAction = "*";
        if(getId("v4").style.background === colorString) this.element.action.tAction = "/";
        if(getId("v5").style.background === colorString) this.element.action.tAction = "%";
    }

    setBasicBlockContent() {
        this.element.content = this.element.action.tRes;
        this.element.content += " = ";
        this.element.content += this.element.action.tA;
        this.element.content += " ";
        this.element.content += this.element.action.tAction;
        this.element.content += " ";
        this.element.content += this.element.action.tB;
    }

    addClickEventToBasicBlock() {
        this.submitBtn.onclick = () => {
            if(this.element) {
                this.element.action = {
                    tRes: this.resultField.value,
                    tA: this.partA.value,
                    tB: this.partB.value,
                };
                this.controlBasicBlockAction();
                this.setBasicBlockContent();
            }
            Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
        };
    }

    addClickEventToPrintBlock() {
        getId("b999").onclick = () => {
            if(this.element) {
                this.element.action = {
                    info: getId("t888").value,
                };
                this.element.content = "Write " + this.element.action.info;
            }
            Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
        };
    }

    addClickEventToReadDataBlock() {
        getId("b1b2b3").onclick = () => {
            if(this.element) {
                this.element.action = {
                    read: getId("t1t2t3").value,
                };
                this.element.content = "Read " + this.element.action.read;
            }
            Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
        };
    }

    controlIfElseBlockAction() {
        const colorString = "rgb(26, 142, 27)";
        if(getId("q1").style.background === colorString) this.element.action.act = "==";
        if(getId("q2").style.background === colorString) this.element.action.act = "<";
        if(getId("q3").style.background === colorString) this.element.action.act = "<=";
    }

    setIfElseBlockContent() {
        this.element.content = this.element.action.firstElement;
        this.element.content += " ";
        this.element.content += this.element.action.act;
        this.element.content += " ";
        this.element.content += this.element.action.secondElement;
    }

    addClickEventToIfElseBlock() {
        getId("b111").onclick = () => {
            if(this.element) {
                this.element.action = {
                    firstElement: getId("t222").value,
                    secondElement: getId("t333").value,
                };
                this.controlIfElseBlockAction();
                this.setIfElseBlockContent();
            }
            Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
        };
    }

    constructor() {
        console.log("Create PropsManager");
        // init
        this.initDomElements();
        // init elem
        this.element = null;
        // read block ok btn
        this.addClickEventToReadDataBlock();
        // basic block ok btn
        this.addClickEventToBasicBlock();
        // print block ok btn
        this.addClickEventToPrintBlock();
        // if else block ok btn
        this.addClickEventToIfElseBlock();
        // act buttons events
        this.addActionsToActButtons();
    }

    addActionsToActButtons() {
        // v type buttons
        this.addActionControl("v1");
        this.addActionControl("v2");
        this.addActionControl("v3");
        this.addActionControl("v4");
        this.addActionControl("v5");
        // q type buttons
        this.addActionControlQQQ("q1");
        this.addActionControlQQQ("q2");
        this.addActionControlQQQ("q3");
    }

    addActionControlQQQ(qqq) {
        getId(qqq.toString()).onclick = () => {
            for(let i = 1; i <= 3; i++) getId("q" + i.toString()).style.background = "#0000FF";
            getId(qqq.toString()).style.background = "#1a8e1b";
        }
    }

    addActionControl(vvv) {
        getId(vvv.toString()).onclick = () => {
            for(let i = 1; i <= 5; i++) getId("v" + i.toString()).style.background = "#0000FF";
            getId(vvv.toString()).style.background = "#1a8e1b";
        };
    }

    static manageIfElseAction(element) {
        if(element.action.act === "==") getId("q1").style.background = "#1a8e1b";
        if(element.action.act === "<") getId("q2").style.background = "#1a8e1b";
        if(element.action.act === "<=") getId("q3").style.background = "#1a8e1b";
    }

    static initIfElseBlockFields(element) {
        getId("t222").value = element.action.firstElement;
        getId("t333").value = element.action.secondElement;
    }

    printPropsOfVetvlenie() {
        const element = this.element;
        PropsManager.initIfElseBlockFields(element);
        PropsManager.allButtonsQ();
        PropsManager.manageIfElseAction(element);
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    }

    printPropsOfPrintingBlock() {
        const element = this.element;
        getId("t888").value = element.action.info;
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    }

    printPropsOfInputDataBox() {
        const element = this.element;
        getId("t1t2t3").value = element.action.read;
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    }

    static allButtonsQ() {
        for(let i = 1; i <= 3; i++) {
            getId("q" + i.toString()).style.background = "#0000FF";
        }
    }

    static allButtonsV() {
        for(let i = 1; i <= 5; i++) {
            getId("v" + i.toString()).style.background = "#0000FF";
        }
    }

    initBasicBlockFields(element) {
        this.resultField.value = element.action.tRes;
        this.partA.value = element.action.tA;
        this.partB.value = element.action.tB;
    }

    static manageBasicBlockAction(element) {
        if(element.action.tAction === "+") getId("v1").style.background = "#1a8e1b";
        if(element.action.tAction === "-") getId("v2").style.background = "#1a8e1b";
        if(element.action.tAction === "*") getId("v3").style.background = "#1a8e1b";
        if(element.action.tAction === "/") getId("v4").style.background = "#1a8e1b";
        if(element.action.tAction === "%") getId("v5").style.background = "#1a8e1b";
    }

    printProps() {
        const element = this.element;
        this.initBasicBlockFields(element);
        PropsManager.allButtonsV();
        PropsManager.manageBasicBlockAction(element);
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    }

    workProps(element) {
        if(element.content === "") {
            element.action = {
                tRes: "",
                tA: "",
                tB: "",
                tAction: "+"
            }
        }
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
        this.element = element;
        this.printProps();
    }

    workPropsOfVetvlenie(element) {
        if(element.content === "") {
            element.action = {
                firstElement: "",
                secondElement: "",
                act: "=="
            }
        }
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
        this.element = element;
        this.printPropsOfVetvlenie();
    }

    workPropsOfPrintingElements(element) {
        if(element.content === "") {
            element.action = {
                info: ""
            }
        }
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
        this.element = element;
        this.printPropsOfPrintingBlock();
    }

    workPropsWithInputDataBox(element) {
        if(element.content === "") {
            element.action = {
                read: ""
            }
        }
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
        this.element = element;
        this.printPropsOfInputDataBox();
    }
}
/* harmony export (immutable) */ __webpack_exports__["a"] = PropsManager;



/***/ }),
/* 7 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = leftMenuScroll;


function getId(idString) {
    return document.getElementById(idString);
}

function leftMenuScroll() {
    const leftMenu = getId("leftMenu");
    const leftContentMainBox = getId("leftContentMainBox");
    let boxPosition = 0;
    leftMenu.onmousewheel = (event) => {
        const speedMoving = 15;
        const deltaY = parseInt(event.deltaY);
        if(deltaY > 0) {
            boxPosition += speedMoving;
        } else {
            boxPosition -= speedMoving;
        }
        leftContentMainBox.style.marginTop = boxPosition + "px";
    };
}


/***/ }),
/* 8 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = canvasScroll;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




function canvasScroll() {
    const t = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager;
    // control wheel
    t.can.onmousewheel = (event) => {
        const speedMoving = 30;
        const deltaY = parseInt(event.deltaY);
        if(deltaY > 0) {
            t.dy += speedMoving;
        } else {
            t.dy -= speedMoving;
        }
        t.printAllBoxes();
    };
}


/***/ }),
/* 9 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = buttonsScroll;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




function getId(idString) {
    return document.getElementById(idString);
}

const deltaValue = -100;

function buttonsScroll() {
    getId("leftBtn").onclick = function () {
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dx += deltaValue;
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    };

    getId("rightBtn").onclick = function () {
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dx -= deltaValue;
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    };

    getId("topBtn").onclick = function () {
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dy += deltaValue;
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    };

    getId("bottomBtn").onclick = function () {
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dy -= deltaValue;
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    };
}


/***/ }),
/* 10 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = creatingIfElseBlock;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




function getId(idString) {
    return document.getElementById(idString);
}

function creatingIfElseBlock() {
    getId("ifElseBlockBtn").onclick = function() {
        const boxX = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dx * (-1) + 350;
        const boxY = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dy * (-1) + 300;
        const boxWidth = 200;
        const boxHeight = 50;
        const strStartX = boxX + boxWidth / 2;
        const strStartY = boxY + boxHeight;
        const strFinishX = strStartX;
        const strFinishY = strStartY + 100;

        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent.push({
            x: boxX,
            y: boxY,
            w: boxWidth,
            h: boxHeight,
            content: "",
            strFinishX: strFinishX - 50,
            strFinishY: strFinishY,
            strFinishXsecond: strFinishX + 50,
            strFinishYsecond: strFinishY,
            vetvlenie: true,
        });
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    };
}


/***/ }),
/* 11 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = creatingConnectBlock;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




function getId(idString) {
    return document.getElementById(idString);
}

function creatingConnectBlock() {
    getId("connectBlockBtn").onclick = function() {
        const boxX = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dx * (-1) + 350;
        const boxY = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dy * (-1) + 300;
        const boxWidth = 50;
        const boxHeight = 50;
        const strStartX = boxX + boxWidth / 2;
        const strStartY = boxY + boxHeight;
        const strFinishX = strStartX;
        const strFinishY = strStartY + 100;

        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent.push({
            x: boxX,
            y: boxY,
            w: boxWidth,
            h: boxHeight,
            content: "",
            strFinishX: strFinishX,
            strFinishY: strFinishY,
            connection: true,
        });
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    };
}



/***/ }),
/* 12 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = creatingPrintingBlock;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




function getId(idString) {
    return document.getElementById(idString);
}

function creatingPrintingBlock() {
    getId("printVarBlockBtn").onclick = function() {
        const boxX = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dx * (-1) + 350;
        const boxY = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dy * (-1) + 300;
        const boxWidth = 200;
        const boxHeight = 50;
        const strStartX = boxX + boxWidth / 2;
        const strStartY = boxY + boxHeight;
        const strFinishX = strStartX;
        const strFinishY = strStartY + 100;

        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent.push({
            x: boxX,
            y: boxY,
            w: boxWidth,
            h: boxHeight,
            content: "",
            strFinishX: strFinishX,
            strFinishY: strFinishY,
            printingVars: true,
        });
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    };
}



/***/ }),
/* 13 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = creatingBasicBlock;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




function getId(idString) {
    return document.getElementById(idString);
}

function creatingBasicBlock() {
    getId("basicBlockBtn").onclick = function () {
        const boxX = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dx * (-1) + 350;
        const boxY = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dy * (-1) + 300;
        const boxWidth = 200;
        const boxHeight = 50;
        const strStartX = boxX + boxWidth / 2;
        const strStartY = boxY + boxHeight;
        const strFinishX = strStartX;
        const strFinishY = strStartY + 100;

        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent.push({
            x: boxX,
            y: boxY,
            w: boxWidth,
            h: boxHeight,
            content: "",
            strFinishX: strFinishX,
            strFinishY: strFinishY,
            basic: true,
        });
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    };
}



/***/ }),
/* 14 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = createStartB;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




function createStartB() {
    const boxX = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dx * (-1) + 350;
    const boxY = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dy * (-1) + 100;
    const boxWidth = 200;
    const boxHeight = 50;
    const strStartX = boxX + boxWidth / 2;
    const strStartY = boxY + boxHeight;
    const strFinishX = strStartX;
    const strFinishY = strStartY + 100;

    Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent.push({
        x: boxX,
        y: boxY,
        w: boxWidth,
        h: boxHeight,
        content: "Start",
        strFinishX: strFinishX,
        strFinishY: strFinishY,
        startBloc: true,
    });
    Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
}



/***/ }),
/* 15 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = connectBtnControl;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




function getId(idString) {
    return document.getElementById(idString);
}

function connectBtnControl() {
    Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().connectElements = true;

    getId("connectElements").onclick = function () {
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().connectElements = !Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().connectElements;
        if(Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().connectElements === true) {
            getId("connectElements").innerHTML = '<i class="fa fa-link" aria-hidden="true"></i>';
        } else {
            getId("connectElements").innerHTML = '<i class="fa fa-chain-broken" aria-hidden="true"></i>';
        }
    }
}


/***/ }),
/* 16 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = hideShowConsoleEvent;


function getId(idString) {
    return document.getElementById(idString);
}

function hideShowConsoleEvent() {
    getId("hideShowConsoleBtn").onclick = function() {
        getId('consoleBox').hidden = !getId('consoleBox').hidden;
    };
}


/***/ }),
/* 17 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = runProgramEvent;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ProgramRunner__ = __webpack_require__(18);





function getId(idString) {
    return document.getElementById(idString);
}

function runProgramEvent() {
    getId("runProgramBtn").onclick = () => {
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programRunner = null;
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programRunner = new __WEBPACK_IMPORTED_MODULE_1__ProgramRunner__["a" /* default */]();
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programRunner.runProgram();
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programRunner = null;
    };
}



/***/ }),
/* 18 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__DragManage_DragControl__ = __webpack_require__(1);





const START_VALUE = 0;
const CODE_OK = "x11111x11111x111xOKxCODEx11xMaxim";
const CODE_ERROR = "x22222x222x2222xERRORxCODEx22xMaxim";

let count = 0;

class ProgramRunner {
    constructor() {
        count += 1;
        console.log("Create ProgramRunner (number: " + count + ")");
    }

    writeContent(content) {
        this.printIngBox.value += (content + "  ");
        console.log("Write: " + content);
    }

    static getContentArray() {
        const contentArrayGlobal = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent;
        const contentArrayString = JSON.stringify(contentArrayGlobal);
        return JSON.parse(contentArrayString.toString());
    }

    findStartBlock() {
        const arr = this.arr;
        for(let i = 0; i < arr.length; i++) {
            const b = arr[i];
            if(b.startBloc) {
                return b;
            }
        }
        return undefined;
    }

    clearConsole() {
        this.printIngBox = document.getElementById('consoleBoxContentValuesBox');
        this.printIngBox.value = "";
    }

    static hideConsole() {
        document.getElementById('consoleBox').hidden = false;
    }

    initCopyVariablesObject() {
        this.variables = {};
        const objString = JSON.stringify(Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().variablesContent);
        this.variables = JSON.parse(objString.toString());
    }

    runProgram() {
        this.arr = ProgramRunner.getContentArray();
        this.nowBlock = this.findStartBlock();
        // init variables
        this.variables = {};
        // init variables started
        this.initCopyVariablesObject();
        // clear console
        this.clearConsole();
        // hide console
        ProgramRunner.hideConsole();
        // start
        this.startWorking();
    }

    static getHitBlockTochka(xxx, yyy, b) {
        return __WEBPACK_IMPORTED_MODULE_1__DragManage_DragControl__["a" /* default */].inBox(b.x, b.y, b.w, b.h, xxx, yyy) === true;
    }

    static getHitBlockPoint(xxx, yyy, b) {
        if(ProgramRunner.getHitBlockTochka(xxx, yyy, b) === true) return true;
        if(ProgramRunner.getHitBlockTochka(xxx - 10, yyy - 10, b) === true) return true;
        if(ProgramRunner.getHitBlockTochka(xxx + 10, yyy + 10, b) === true) return true;
        if(ProgramRunner.getHitBlockTochka(xxx + 10, yyy - 10, b) === true) return true;
        if(ProgramRunner.getHitBlockTochka(xxx - 10, yyy + 10, b) === true) return true;
        return null;
    }

    workWithContentOfBlock(nowBlock) {
        if(nowBlock.readingDataBox === true) {
            return this.workReadBlock(nowBlock);
        } else if(nowBlock.basic === true) {
            return this.workBasic(nowBlock);
        } else if(nowBlock.printingVars === true) {
            return this.workPrintingBlock(nowBlock);
        } else if(nowBlock.connection === true) {
            return true;
        } else if(nowBlock.vetvlenie === true) {
            return this.workWithIfElseBlock(nowBlock);
        }
        return true;
    }

    controlVariable(param) {
        // is it simple number
        const num = parseInt(param);
        if(isNaN(num) === false) {
            // it is simple number
            return num;
        }

        // it is not number

        // if it is simple variable
        if(param.indexOf("_") === -1) {
            if(this.variables[param] === undefined) {
                this.variables[param] = START_VALUE;
            }
            return this.variables[param];
        }

        // if it is element of array
        const mass = param.split("_");
        const arrayName = mass[0];
        const arrayElem = mass[1];

        if(this.variables[arrayName] === undefined) {
            this.variables[arrayName] = [];
        }

        const n = parseInt(arrayElem);
        if(isNaN(n) === false) {
            // it is number
            return this.variables[arrayName][n];
        } else {
            const k = this.variables[arrayElem];
            return this.variables[arrayName][k];
        }
    }

    controlVariableFinish(param) {
        const resultVar = this.controlVariable(param);
        const resultInt = parseInt(resultVar);
        if(resultInt === null || resultInt === undefined || isNaN(resultInt) === true) {
            return START_VALUE;
        } else {
            return parseInt(resultInt.toString());
        }
    }

    workPrintingBlock(nowBlock) {
        if(nowBlock.action) {
            const action = nowBlock.action;
            const info = this.controlVariableFinish(action.info);
            this.writeContent(info);
            return true;
        }
    }

    workWithIfElseBlock(nowBlock) {
        if(nowBlock.action) {
            const action = nowBlock.action;

            let a = this.controlVariableFinish(action.firstElement);
            let b = this.controlVariableFinish(action.secondElement);
            const act = action.act;

            a = parseInt(a);
            b = parseInt(b);

            let resultFlag = false;

            if(act === "==") {
                if(a === b) {
                    resultFlag = true;
                }
            }

            if(act === "<") {
                if(a < b) {
                    resultFlag = true;
                }
            }

            if(act === "<=") {
                if(a <= b) {
                    resultFlag = true;
                }
            }

            if(resultFlag === true) {
                return CODE_OK;
            } else {
                return CODE_ERROR;
            }
        }
    }

    workReadBlock(nowBlock) {
        if(nowBlock.action) {
            const action = nowBlock.action;
            const read = action.read + "";
            const key = read.toString();

            let value = parseInt(this.inpMass[0]);

            try {
                this.inpMass.splice(0, 1);
            } catch (err) {
                // err
            }

            if(value === null || value === undefined || isNaN(value) === true) {
                value = parseInt(START_VALUE);
            }

            this.variables[key] = parseInt(value);
        }
    }

    workBasic(nowBlock) {
        if(nowBlock.action) {
            const action = nowBlock.action;
            const res = this.controlVariableFinish(action.tRes);
            const a = this.controlVariableFinish(action.tA);
            const b = this.controlVariableFinish(action.tB);
            const toDo = action.tAction;
            let answer = START_VALUE;
            switch (toDo) {
                case "+": answer = a + b; break;
                case "-": answer = a - b; break;
                case "*": answer = a * b; break;
                case "/": answer = a / b; break;
                case "%": answer = a % b; break;
            }
            answer = parseInt(answer.toString());
            const name = action.tRes;
            if(name.indexOf("_") === -1) {
                this.variables[name] = answer;
            } else {
                const mass = name.split("_");
                const arrayName = mass[0];
                const arrayElem = mass[1];

                const n = parseInt(arrayElem);
                if(isNaN(n) === false) {
                    // it is number
                    this.variables[arrayName][n] = answer;
                } else {
                    const k = this.variables[arrayElem];
                    this.variables[arrayName][k] = answer;
                }
            }
        }
    }

    getVariablesFromInputConsole() {
        const consoleField = document.getElementById("consoleBoxContentValuesBoxForInputData");
        const consoleText = consoleField.value + "";
        const arr = consoleText.split(" ");
        this.inpMass = [];
        for(let i = 0; i < arr.length; i++) {
            const x = parseInt(arr[i]);
            if(x === null || x === undefined || isNaN(x) === true) {
                this.inpMass.push(parseInt(START_VALUE));
            } else {
                this.inpMass.push(parseInt(x));
            }
        }
        console.log("Input mass: " + this.inpMass);
    }

    startWorking() {
        this.printIngBox.value = "";
        let nowBlock = this.nowBlock;
        let arr = this.arr;

        this.getVariablesFromInputConsole();

        while(true) {
            const workOutput = this.workWithContentOfBlock(nowBlock);
            if(workOutput !== CODE_OK && workOutput !== CODE_ERROR) {
                // not if else block
                let found = false;
                for (let i = 0; i < arr.length; i++) {
                    const b = arr[i];
                    if (ProgramRunner.getHitBlockPoint(nowBlock.strFinishX, nowBlock.strFinishY, b)) {
                        nowBlock = b;
                        found = true;
                        break;
                    }
                }
                if (found === false) {
                    break;
                }
            } else {
                // it is IfElse block
                let found = false;
                for (let i = 0; i < arr.length; i++) {
                    const b = arr[i];
                    if(workOutput === CODE_OK) {
                        if (ProgramRunner.getHitBlockPoint(nowBlock.strFinishX, nowBlock.strFinishY, b)) {
                            nowBlock = b;
                            found = true;
                            break;
                        }
                    } else {
                        if (ProgramRunner.getHitBlockPoint(nowBlock.strFinishXsecond, nowBlock.strFinishYsecond, b)) {
                            nowBlock = b;
                            found = true;
                            break;
                        }
                    }
                }
                if (found === false) {
                    break;
                }
            }
        }

        this.printVariablesObject();
    }

    printVariablesObject() {
        console.log("Variables: ");
        console.log(this.variables);
    }
}
/* harmony export (immutable) */ __webpack_exports__["a"] = ProgramRunner;



/***/ }),
/* 19 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = jqueryManager;


function jqueryManager() {
    const $ = __webpack_require__(20);
    const waitTime = 300;

    $("#argumentsBtn").click(function() {
        $("#argumentsBoxContent").slideToggle(waitTime);
    });

    $("#blokiBtn").click(function() {
        $("#blocksBtnBox").slideToggle(waitTime);
    });

    $("#sodergimBtn").click(function () {
        $("#sodergimoeBox").slideToggle(waitTime);
    });
}


/***/ }),
/* 20 */
/***/ (function(module, exports) {

module.exports = require("jquery");

/***/ }),
/* 21 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




const START_VALUE = 0;

function getId(idString) {
    return document.getElementById(idString);
}

class InitVarsControl {
    initFieldsAndButtons() {
        this.nameField = getId("addArgLabelName");
        this.valueField = getId("addArgLabelValue");
        this.addBtn = getId("argAddBtn");
        this.clearBtn = getId("argClearBtn");
        this.argsBoxWithTable = getId("argsBoxWithTable");
    }

    drawTable() {
        this.argsBoxWithTable.innerHTML = "";
        let contentString = "";
        contentString += "<table><tbody><tr><td><b>Имя</b></td><td><b>Значение</b></td></tr>";
        for(let key in Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().variablesContent) {
            const value = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().variablesContent[key.toString()];
            const resultName = key.toString();
            const resultValue = parseInt(value);
            contentString += `<tr><td>${resultName}</td><td>${resultValue}</td></tr>`;
        }
        this.argsBoxWithTable.innerHTML = "";
        contentString += "</tbody></table>";
        this.argsBoxWithTable.innerHTML = contentString.toString();
    }

    addEventToClearBtn() {
        this.clearBtn.onclick = () => {
            this.clearTextFields();
            Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().variablesContent = {};
            // draw table
            this.drawTable();
        };
    }

    clearTextFields() {
        this.nameField.value = "";
        this.valueField.value = "";
    }

    addEventToAddingBtn() {
        this.addBtn.onclick = () => {
            if(this.nameField.value && this.valueField.value) {
                let nameContent = this.nameField.value;
                let valueContent = parseInt(this.valueField.value);
                if(valueContent === null || valueContent === undefined || isNaN(valueContent) === true) {
                    valueContent = START_VALUE;
                }
                this.clearTextFields();
                Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().variablesContent[nameContent] = parseInt(valueContent);
                // draw table
                this.drawTable();
            }
        }
    }

    constructor() {
        console.log("Create InitVarsControl");
        // init DOM elements
        this.initFieldsAndButtons();
        // add event to add btn
        this.addEventToAddingBtn();
        // add event to clear btn
        this.addEventToClearBtn();
        // draw table
        this.drawTable();
    }
}
/* harmony export (immutable) */ __webpack_exports__["a"] = InitVarsControl;



/***/ }),
/* 22 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = controlScale;


function getId(idString) {
    return document.getElementById(idString);
}

function controlScale() {
    const {webFrame} = __webpack_require__(2);

    let zoomValue = webFrame.getZoomFactor();

    const deltaZoom = 0.2;
    const maxZoom = 1.3;
    const minZoom = 0.7;

    function setWindowZoom(value) {
        webFrame.setZoomFactor(value);
    }

    function plusZoom() {
        if(zoomValue < maxZoom) {
            zoomValue += deltaZoom;
            setWindowZoom(zoomValue);
        }
    }

    function minusZoom() {
        if(zoomValue > minZoom) {
            zoomValue -= deltaZoom;
            setWindowZoom(zoomValue);
        }
    }

    getId("plusZoomBtn").onclick = function() {
        plusZoom();
    };

    getId("minusZoomBtn").onclick = function() {
        minusZoom();
    };
}


/***/ }),
/* 23 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = saveProjectFile;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




function getId(idString) {
    return document.getElementById(idString);
}

function saveProjectFile() {
    const fs = __webpack_require__(3);
    const {dialog} = __webpack_require__(2).remote;

    getId("projectWorkBtnSave").onclick = function () {
        dialog.showSaveDialog((fileName) => {
            console.log(fileName);
            if(fileName !== undefined) {
                const obj = {
                    programContent: Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent,
                    variablesContent: Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().variablesContent,
                };
                const contentFile = JSON.stringify(obj);
                fs.writeFile(fileName, contentFile, function(err) {
                    if(!err) {
                        console.log("--- Save file OK ---");
                    }
                });
            }
        });
    }
}


/***/ }),
/* 24 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = loadProjectFile;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__DragManage_DragControl__ = __webpack_require__(1);





function getId(idString) {
    return document.getElementById(idString);
}

function setSelectValueNull(arr) {
    arr.forEach((block) => {
        block.selectValue = null;
    });
}

function loadProjectFile() {
    const fs = __webpack_require__(3);
    const {dialog} = __webpack_require__(2).remote;

    getId("projectWorkBtnLoad").onclick = function () {
        dialog.showOpenDialog((fileName) => {
            console.log(fileName);
            if(fileName !== undefined) {
                fs.readFile(fileName[0], 'utf8', function(err, content) {
                    try {
                        const obj = JSON.parse(content);
                        // init global
                        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent = obj.programContent;
                        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().variablesContent = obj.variablesContent;
                        // all not selected
                        setSelectValueNull(Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent);
                        // draw content
                        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.initDeltaXY();
                        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.clearFon();
                        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
                        // draw start fields table
                        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().initVarsControl.drawTable();
                        // set no content block visible
                        __WEBPACK_IMPORTED_MODULE_1__DragManage_DragControl__["a" /* default */].hideBoxes();
                        document.getElementById("contentOfNoContentBox").hidden = false;
                    } catch (err) {
                        // err
                    }
                });
            }
        });
    }
}


/***/ }),
/* 25 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = createReadBlock;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__ = __webpack_require__(0);




function getId(idString) {
    return document.getElementById(idString);
}

function createReadBlock() {
    getId('inputDataBlockBtn').onclick = function() {
        const boxX = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dx * (-1) + 350;
        const boxY = Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.dy * (-1) + 300;
        const boxWidth = 200;
        const boxHeight = 50;
        const strStartX = boxX + boxWidth / 2;
        const strStartY = boxY + boxHeight;
        const strFinishX = strStartX;
        const strFinishY = strStartY + 100;

        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().programContent.push({
            x: boxX,
            y: boxY,
            w: boxWidth,
            h: boxHeight,
            content: "",
            strFinishX: strFinishX,
            strFinishY: strFinishY,
            readingDataBox: true,
        });
        Object(__WEBPACK_IMPORTED_MODULE_0__GlobalObjStore_global__["a" /* default */])().canvasManager.printAllBoxes();
    }
}



/***/ })
/******/ ]);