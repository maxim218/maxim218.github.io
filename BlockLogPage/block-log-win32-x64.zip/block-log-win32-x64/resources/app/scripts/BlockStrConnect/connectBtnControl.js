"use strict";

import global from "../GlobalObjStore/global";

function getId(idString) {
    return document.getElementById(idString);
}

export default function connectBtnControl() {
    global().connectElements = true;

    getId("connectElements").onclick = function () {
        global().connectElements = !global().connectElements;
        if(global().connectElements === true) {
            getId("connectElements").innerHTML = '<i class="fa fa-link" aria-hidden="true"></i>';
        } else {
            getId("connectElements").innerHTML = '<i class="fa fa-chain-broken" aria-hidden="true"></i>';
        }
    }
}
