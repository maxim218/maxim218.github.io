"use strict";

import global from "../GlobalObjStore/global";

function getId(idString) {
    return document.getElementById(idString);
}

export default class PropsManager {
    initDomElements() {
        this.resultField = getId("t1");
        this.partA = getId("t2");
        this.partB = getId("t3");
        this.submitBtn = getId("b1");
    }

    controlBasicBlockAction() {
        const colorString = "rgb(26, 142, 27)";
        if(getId("v1").style.background === colorString) this.element.action.tAction = "+";
        if(getId("v2").style.background === colorString) this.element.action.tAction = "-";
        if(getId("v3").style.background === colorString) this.element.action.tAction = "*";
        if(getId("v4").style.background === colorString) this.element.action.tAction = "/";
        if(getId("v5").style.background === colorString) this.element.action.tAction = "%";
    }

    setBasicBlockContent() {
        this.element.content = this.element.action.tRes;
        this.element.content += " = ";
        this.element.content += this.element.action.tA;
        this.element.content += " ";
        this.element.content += this.element.action.tAction;
        this.element.content += " ";
        this.element.content += this.element.action.tB;
    }

    addClickEventToBasicBlock() {
        this.submitBtn.onclick = () => {
            if(this.element) {
                this.element.action = {
                    tRes: this.resultField.value,
                    tA: this.partA.value,
                    tB: this.partB.value,
                };
                this.controlBasicBlockAction();
                this.setBasicBlockContent();
            }
            global().canvasManager.printAllBoxes();
        };
    }

    addClickEventToPrintBlock() {
        getId("b999").onclick = () => {
            if(this.element) {
                this.element.action = {
                    info: getId("t888").value,
                };
                this.element.content = "Write " + this.element.action.info;
            }
            global().canvasManager.printAllBoxes();
        };
    }

    addClickEventToReadDataBlock() {
        getId("b1b2b3").onclick = () => {
            if(this.element) {
                this.element.action = {
                    read: getId("t1t2t3").value,
                };
                this.element.content = "Read " + this.element.action.read;
            }
            global().canvasManager.printAllBoxes();
        };
    }

    controlIfElseBlockAction() {
        const colorString = "rgb(26, 142, 27)";
        if(getId("q1").style.background === colorString) this.element.action.act = "==";
        if(getId("q2").style.background === colorString) this.element.action.act = "<";
        if(getId("q3").style.background === colorString) this.element.action.act = "<=";
    }

    setIfElseBlockContent() {
        this.element.content = this.element.action.firstElement;
        this.element.content += " ";
        this.element.content += this.element.action.act;
        this.element.content += " ";
        this.element.content += this.element.action.secondElement;
    }

    addClickEventToIfElseBlock() {
        getId("b111").onclick = () => {
            if(this.element) {
                this.element.action = {
                    firstElement: getId("t222").value,
                    secondElement: getId("t333").value,
                };
                this.controlIfElseBlockAction();
                this.setIfElseBlockContent();
            }
            global().canvasManager.printAllBoxes();
        };
    }

    constructor() {
        console.log("Create PropsManager");
        // init
        this.initDomElements();
        // init elem
        this.element = null;
        // read block ok btn
        this.addClickEventToReadDataBlock();
        // basic block ok btn
        this.addClickEventToBasicBlock();
        // print block ok btn
        this.addClickEventToPrintBlock();
        // if else block ok btn
        this.addClickEventToIfElseBlock();
        // act buttons events
        this.addActionsToActButtons();
    }

    addActionsToActButtons() {
        // v type buttons
        this.addActionControl("v1");
        this.addActionControl("v2");
        this.addActionControl("v3");
        this.addActionControl("v4");
        this.addActionControl("v5");
        // q type buttons
        this.addActionControlQQQ("q1");
        this.addActionControlQQQ("q2");
        this.addActionControlQQQ("q3");
    }

    addActionControlQQQ(qqq) {
        getId(qqq.toString()).onclick = () => {
            for(let i = 1; i <= 3; i++) getId("q" + i.toString()).style.background = "#0000FF";
            getId(qqq.toString()).style.background = "#1a8e1b";
        }
    }

    addActionControl(vvv) {
        getId(vvv.toString()).onclick = () => {
            for(let i = 1; i <= 5; i++) getId("v" + i.toString()).style.background = "#0000FF";
            getId(vvv.toString()).style.background = "#1a8e1b";
        };
    }

    static manageIfElseAction(element) {
        if(element.action.act === "==") getId("q1").style.background = "#1a8e1b";
        if(element.action.act === "<") getId("q2").style.background = "#1a8e1b";
        if(element.action.act === "<=") getId("q3").style.background = "#1a8e1b";
    }

    static initIfElseBlockFields(element) {
        getId("t222").value = element.action.firstElement;
        getId("t333").value = element.action.secondElement;
    }

    printPropsOfVetvlenie() {
        const element = this.element;
        PropsManager.initIfElseBlockFields(element);
        PropsManager.allButtonsQ();
        PropsManager.manageIfElseAction(element);
        global().canvasManager.printAllBoxes();
    }

    printPropsOfPrintingBlock() {
        const element = this.element;
        getId("t888").value = element.action.info;
        global().canvasManager.printAllBoxes();
    }

    printPropsOfInputDataBox() {
        const element = this.element;
        getId("t1t2t3").value = element.action.read;
        global().canvasManager.printAllBoxes();
    }

    static allButtonsQ() {
        for(let i = 1; i <= 3; i++) {
            getId("q" + i.toString()).style.background = "#0000FF";
        }
    }

    static allButtonsV() {
        for(let i = 1; i <= 5; i++) {
            getId("v" + i.toString()).style.background = "#0000FF";
        }
    }

    initBasicBlockFields(element) {
        this.resultField.value = element.action.tRes;
        this.partA.value = element.action.tA;
        this.partB.value = element.action.tB;
    }

    static manageBasicBlockAction(element) {
        if(element.action.tAction === "+") getId("v1").style.background = "#1a8e1b";
        if(element.action.tAction === "-") getId("v2").style.background = "#1a8e1b";
        if(element.action.tAction === "*") getId("v3").style.background = "#1a8e1b";
        if(element.action.tAction === "/") getId("v4").style.background = "#1a8e1b";
        if(element.action.tAction === "%") getId("v5").style.background = "#1a8e1b";
    }

    printProps() {
        const element = this.element;
        this.initBasicBlockFields(element);
        PropsManager.allButtonsV();
        PropsManager.manageBasicBlockAction(element);
        global().canvasManager.printAllBoxes();
    }

    workProps(element) {
        if(element.content === "") {
            element.action = {
                tRes: "",
                tA: "",
                tB: "",
                tAction: "+"
            }
        }
        global().canvasManager.printAllBoxes();
        this.element = element;
        this.printProps();
    }

    workPropsOfVetvlenie(element) {
        if(element.content === "") {
            element.action = {
                firstElement: "",
                secondElement: "",
                act: "=="
            }
        }
        global().canvasManager.printAllBoxes();
        this.element = element;
        this.printPropsOfVetvlenie();
    }

    workPropsOfPrintingElements(element) {
        if(element.content === "") {
            element.action = {
                info: ""
            }
        }
        global().canvasManager.printAllBoxes();
        this.element = element;
        this.printPropsOfPrintingBlock();
    }

    workPropsWithInputDataBox(element) {
        if(element.content === "") {
            element.action = {
                read: ""
            }
        }
        global().canvasManager.printAllBoxes();
        this.element = element;
        this.printPropsOfInputDataBox();
    }
}
