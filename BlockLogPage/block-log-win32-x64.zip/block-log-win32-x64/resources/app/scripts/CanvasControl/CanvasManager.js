"use strict";

import global from "../GlobalObjStore/global";

const BACKGROUND_COLOR = '#CCCCCC';
const WWW = 2500;
const HHH = 2500;

export default class CanvasManager {
    initDeltaXY() {
        this.dx = 0;
        this.dy = 0;
    }

    initCanvasAndHolst() {
        this.can = document.getElementById('can');
        this.holst = this.can.getContext('2d');
    }

    createEventsFields() {
        this.mouseDownAction = function () {};
        this.mouseUpAction = function () {};
        this.mouseMoveAction = function () {};
    }

    initMouseDownEvent() {
        this.can.onmousedown = (event) => {
            const xMouse = parseInt(event.offsetX);
            const yMouse = parseInt(event.offsetY);
            this.mouseDownAction(xMouse, yMouse);
        };
    }

    initMouseUpEvent() {
        this.can.onmouseup = (event) => {
            const xMouse = parseInt(event.offsetX);
            const yMouse = parseInt(event.offsetY);
            this.mouseUpAction(xMouse, yMouse);
        };
    }

    initMouseMoveEvent() {
        this.can.onmousemove = (event) => {
            const xMouse = parseInt(event.offsetX);
            const yMouse = parseInt(event.offsetY);
            this.mouseMoveAction(xMouse, yMouse);
        };
    }

    loadImage() {
        this.myImg = new Image();
        this.myImg.src = ("paper.jpg");
        this.myImg.onload = () => {
            console.log("-- Load paper image OK --");
            // draw empty fon
            this.clearFon();
            // print content
            this.printAllBoxes();
        }
    }

    constructor() {
        console.log("Create CanvasManager");
        // init
        this.initDeltaXY();
        this.initCanvasAndHolst();
        this.createEventsFields();
        // init mouse events fields
        this.initMouseDownEvent();
        this.initMouseUpEvent();
        this.initMouseMoveEvent();
        // load image
        this.loadImage();
        // draw empty fon
        this.clearFon();
        // init draw line mode
        this.allowDrawLine = true;
    }

    drawImage() {
        const deltaSize = 300;
        try {
            for(let i = 0; i < 11; i++) {
                for(let j = 0; j < 11; j++) {
                    this.holst.drawImage(this.myImg, i * deltaSize, j * deltaSize, deltaSize, deltaSize);
                }
            }
        } catch (err) {
            // err
        }
    }

    clearFon() {
        this.holst.fillStyle = BACKGROUND_COLOR;
        const startValue = 0;
        // clear content
        this.holst.clearRect(startValue, startValue, WWW, HHH);
        // draw background
        this.holst.fillRect(startValue, startValue, WWW, HHH);
        // draw image
        this.drawImage();
    }

    setBoxBorderColor(flag) {
        if(flag) {
            this.setStrokeColor('#ff211c');
        } else {
            this.setStrokeColor('#0000FF');
        }
    }

    renderText(x, y, content) {
        this.holst.fillStyle = '#000000';
        this.holst.font = "15px Arial";
        this.holst.fillText(content,x + 10,y + 30);
    }

    drawSquareForBox(x, y, w, h) {
        this.holst.fillStyle = '#FFFFFF';
        this.holst.fillRect(x, y, w, h);
        this.holst.lineWidth = 1;
        this.holst.fillStyle = '#000000';
        this.holst.strokeRect(x, y, w, h);
    }

    drawBox(x, y, w, h, content, flag) {
        this.setBoxBorderColor(flag);
        this.drawSquareForBox(x, y, w, h);
        this.renderText(x, y, content);
    }

    drawStr(x1, y1, x2, y2, color) {
        this.setStrokeColor(color);
        this.holst.lineWidth = 3;
        this.drawSimpleLine(x1, y1, x2, y2);
        this.drawLittleKv(x2, y2);
    }

    setStrokeColor(color) {
        if(!color) {
            this.holst.strokeStyle = '#000000';
        } else {
            this.holst.strokeStyle = color;
        }
    }

    drawSimpleLine(x1, y1, x2, y2) {
        if(this.allowDrawLine === true) {
            this.holst.beginPath();
            this.holst.moveTo(x1, y1);
            this.holst.lineTo(x2, y2);
            this.holst.closePath();
            this.holst.stroke();
        }
    }

    drawLittleKv(x2, y2) {
        // little square
        this.holst.fillStyle = '#c39ecc';
        this.holst.strokeStyle = '#0000FF';
        this.holst.fillRect(x2 - 10, y2 - 10, 20, 20);
        this.holst.strokeRect(x2 - 10, y2 - 10, 20, 20);
    }

    printAllWithDrawLine(arr, yesColor, noColor) {
        for(let i = 0; i < arr.length; i++) {
            const box = arr[i];
            const strStartX = box.x + this.dx + box.w / 2;
            const strStartY = box.y + this.dy + box.h;
            if(!box.vetvlenie) {
                this.drawStr(strStartX, strStartY, box.strFinishX + this.dx, box.strFinishY + this.dy);
            } else {
                this.drawStr(strStartX, strStartY, box.strFinishX + this.dx, box.strFinishY + this.dy, yesColor);
                this.drawStr(strStartX, strStartY, box.strFinishXsecond + this.dx, box.strFinishYsecond + this.dy, noColor);
            }
            if(!box.selectValue) {
                this.drawBox(box.x + this.dx, box.y + this.dy, box.w, box.h, box.content);
            } else {
                this.drawBox(box.x + this.dx, box.y + this.dy, box.w, box.h, box.content, true);
            }
        }
    }

    printAllWithNotDrawLine(arr, yesColor, noColor) {
        for(let i = 0; i < arr.length; i++) {
            const box = arr[i];
            const strStartX = box.x + this.dx + box.w / 2;
            const strStartY = box.y + this.dy + box.h;
            if(!box.vetvlenie) {
                this.drawStr(strStartX, strStartY, box.strFinishX + this.dx, box.strFinishY + this.dy);
            } else {
                this.drawStr(strStartX, strStartY, box.strFinishX + this.dx, box.strFinishY + this.dy, yesColor);
                this.drawStr(strStartX, strStartY, box.strFinishXsecond + this.dx, box.strFinishYsecond + this.dy, noColor);
            }
        }
    }

    printAllBoxes() {
        // clear content
        this.clearFon();
        // get array of boxes
        const arr = global().programContent;
        // init colors
        const yesColor = "#00FF00";
        const noColor = "#FF0000";
        // init draw line mode
        this.allowDrawLine = true;
        // print with YES mode
        this.printAllWithDrawLine(arr, yesColor, noColor);
        // init draw line mode
        this.allowDrawLine = false;
        // print with NO mode
        this.printAllWithNotDrawLine(arr, yesColor, noColor);
    }
}

