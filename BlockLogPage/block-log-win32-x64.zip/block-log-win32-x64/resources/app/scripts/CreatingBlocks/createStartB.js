"use strict";

import global from "../GlobalObjStore/global";

export default function createStartB() {
    const boxX = global().canvasManager.dx * (-1) + 350;
    const boxY = global().canvasManager.dy * (-1) + 100;
    const boxWidth = 200;
    const boxHeight = 50;
    const strStartX = boxX + boxWidth / 2;
    const strStartY = boxY + boxHeight;
    const strFinishX = strStartX;
    const strFinishY = strStartY + 100;

    global().programContent.push({
        x: boxX,
        y: boxY,
        w: boxWidth,
        h: boxHeight,
        content: "Start",
        strFinishX: strFinishX,
        strFinishY: strFinishY,
        startBloc: true,
    });
    global().canvasManager.printAllBoxes();
}

