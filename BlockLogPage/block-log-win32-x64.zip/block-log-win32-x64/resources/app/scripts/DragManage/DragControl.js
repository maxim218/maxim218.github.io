"use strict";

import global from "../GlobalObjStore/global";

const BOX = "box";
const STR = "str";
const STR_SECOND = "str_second";

export default class DragControl {
    static inBox(boxX, boxY, boxW, boxH, xx, yy) {
        if(boxX <= xx && xx <= boxX + boxW) {
            if(boxY <= yy && yy <= boxY + boxH) {
                return true;
            }
        }
        return false;
    }

    static hideBoxes() {
        document.getElementById("contentOfBlockBox").hidden = true;
        document.getElementById("contentOfVetvlenieBox").hidden = true;
        document.getElementById("contentOfPrintingBox").hidden = true;
        document.getElementById("contentOfNoContentBox").hidden = true;
        document.getElementById("readBoxCCCCCC").hidden = true;
    }

    setElement(element) {
        this.selectedToChange = null;
        const arr = global().programContent;
        for(let i = 0; i < arr.length; i++) {
            const b = arr[i];
            b.selectValue = null;
        }
        this.selectedToChange = element;
    }

    callWorkingPropsOfBlock() {
        if(global().propsManager) {
            if(this.selectedToChange.basic === true) {
                global().propsManager.workProps(this.selectedToChange);
                document.getElementById("contentOfBlockBox").hidden = false;
            } else if(this.selectedToChange.vetvlenie === true) {
                global().propsManager.workPropsOfVetvlenie(this.selectedToChange);
                document.getElementById("contentOfVetvlenieBox").hidden = false;
            } else if(this.selectedToChange.printingVars === true) {
                global().propsManager.workPropsOfPrintingElements(this.selectedToChange);
                document.getElementById("contentOfPrintingBox").hidden = false;
            } else if(this.selectedToChange.readingDataBox === true) {
                global().propsManager.workPropsWithInputDataBox(this.selectedToChange);
                document.getElementById("readBoxCCCCCC").hidden = false;
            } else {
                document.getElementById("contentOfNoContentBox").hidden = false;
            }
        }
    }

    setSelectedToChange(element) {
        this.setElement(element);
        if(this.selectedToChange) {
            this.selectedToChange.selectValue = true;
            DragControl.hideBoxes();
            this.callWorkingPropsOfBlock();
        }
        global().canvasManager.printAllBoxes();
    }

    initMouseUpAction() {
        global().canvasManager.mouseUpAction = (xxx, yyy) => {
            this.selected = null;
            this.deltaX = 0;
            this.deltaY = 0;
            this.type = null;
        };
    }

    controlFirstStr(arr, dx, dy, xxx, yyy) {
        for(let i = arr.length - 1; i >= 0; i--) {
            const b = arr[i];
            if (DragControl.inBox(b.strFinishX + dx - 10, b.strFinishY + dy - 10, 20, 20, xxx, yyy) === true) {
                this.selected = b;
                this.deltaX = xxx - b.strFinishX;
                this.deltaY = yyy - b.strFinishY;
                this.type = STR;
                return true;
            }
        }
        return false;
    }

    controlSecondStr(arr, dx, dy, xxx, yyy) {
        for(let i = arr.length - 1; i >= 0; i--) {
            const b = arr[i];
            if (b.vetvlenie) {
                if (DragControl.inBox(b.strFinishXsecond + dx - 10, b.strFinishYsecond + dy - 10, 20, 20, xxx, yyy) === true) {
                    this.selected = b;
                    this.deltaX = xxx - b.strFinishXsecond;
                    this.deltaY = yyy - b.strFinishYsecond;
                    this.type = STR_SECOND;
                    return true;
                }
            }
        }
        return false;
    }

    controlBox(arr, dx, dy, xxx, yyy) {
        for(let i = arr.length - 1; i >= 0; i--) {
            const b = arr[i];
            if(DragControl.inBox(b.x + dx, b.y + dy, b.w, b.h, xxx, yyy) === true) {
                this.selected = b;
                this.setSelectedToChange(this.selected);
                this.deltaX = xxx - b.x;
                this.deltaY = yyy - b.y;
                this.type = BOX;
                return true;
            }
        }
        return false;
    }

    initMouseDownAction() {
        global().canvasManager.mouseDownAction = (xxx, yyy) => {
            const dx = global().canvasManager.dx;
            const dy = global().canvasManager.dy;
            const arr = global().programContent;
            if(!this.controlFirstStr(arr, dx, dy, xxx, yyy)) {
                if(!this.controlSecondStr(arr, dx, dy, xxx, yyy)) {
                    if(!this.controlBox(arr, dx, dy, xxx, yyy)) {
                        console.log("No hit");
                    }
                }
            }
        };
    }

    initFields() {
        this.selectedToChange = null;
        this.setSelectedToChange(null);
        this.selected = null;
        this.deltaX = 0;
        this.deltaY = 0;
        this.type = null;
    }

    workIfConnectElementsTrue(xxx, yyy) {
        if(global().connectElements === true) {
            this.selected.strFinishX = xxx - this.deltaX + this.selected.w / 2;
            this.selected.strFinishY = yyy - this.deltaY + this.selected.h + 100;
            if(this.selected.vetvlenie) {
                this.selected.strFinishX = xxx - this.deltaX + this.selected.w / 2 - 50;
                this.selected.strFinishY = yyy - this.deltaY + this.selected.h + 100;
                this.selected.strFinishXsecond = xxx - this.deltaX + this.selected.w / 2 + 50;
                this.selected.strFinishYsecond = yyy - this.deltaY + this.selected.h + 100;
            }
        }
    }

    controlStrFirst(xxx, yyy) {
        this.selected.strFinishX = xxx - this.deltaX;
        this.selected.strFinishY = yyy - this.deltaY;
        global().canvasManager.printAllBoxes();
    }

    controlStrSecond(xxx, yyy) {
        this.selected.strFinishXsecond = xxx - this.deltaX;
        this.selected.strFinishYsecond = yyy - this.deltaY;
        global().canvasManager.printAllBoxes();
    }

    initMouseMoveAction() {
        global().canvasManager.mouseMoveAction = (xxx, yyy) => {
            if(this.selected !== null) {
                if(this.type === BOX) {
                    this.selected.x = xxx - this.deltaX;
                    this.selected.y = yyy - this.deltaY;
                    this.workIfConnectElementsTrue(xxx, yyy);
                    global().canvasManager.printAllBoxes();
                } else if(this.type === STR) {
                    this.controlStrFirst(xxx, yyy);
                } else if(this.type === STR_SECOND) {
                    this.controlStrSecond(xxx, yyy);
                }
            }
        };
    }

    addEventToDeletingBtn() {
        const xxxValue = -999999999;
        document.getElementById("deleteBlockBtn").onclick = () => {
            if(this.selectedToChange) {
                if(this.selectedToChange.content !== "Start") {
                    this.selectedToChange.x = xxxValue;
                    this.selectedToChange.y = xxxValue;
                    this.selectedToChange.strFinishX = xxxValue;
                    this.selectedToChange.strFinishY = xxxValue;
                    this.selectedToChange.strFinishXsecond = xxxValue;
                    this.selectedToChange.strFinishYsecond = xxxValue;
                }
            }
            // no content
            DragControl.hideBoxes();
            document.getElementById("contentOfNoContentBox").hidden = false;
            // redraw canvas
            global().canvasManager.clearFon();
            global().canvasManager.printAllBoxes();
        }
    }

    constructor() {
        console.log("Create DragControl");
        // init
        this.initFields();
        // mouse events
        this.initMouseDownAction();
        this.initMouseUpAction();
        this.initMouseMoveAction();
        // delete btn event
        this.addEventToDeletingBtn();
    }
}
