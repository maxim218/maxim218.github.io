"use strict";

import global from "./../GlobalObjStore/global";
import DragControl from "./../DragManage/DragControl";

function getId(idString) {
    return document.getElementById(idString);
}

function setSelectValueNull(arr) {
    arr.forEach((block) => {
        block.selectValue = null;
    });
}

export default function loadProjectFile() {
    const fs = require('fs');
    const {dialog} = require('electron').remote;

    getId("projectWorkBtnLoad").onclick = function () {
        dialog.showOpenDialog((fileName) => {
            console.log(fileName);
            if(fileName !== undefined) {
                fs.readFile(fileName[0], 'utf8', function(err, content) {
                    try {
                        const obj = JSON.parse(content);
                        // init global
                        global().programContent = obj.programContent;
                        global().variablesContent = obj.variablesContent;
                        // all not selected
                        setSelectValueNull(global().programContent);
                        // draw content
                        global().canvasManager.initDeltaXY();
                        global().canvasManager.clearFon();
                        global().canvasManager.printAllBoxes();
                        // draw start fields table
                        global().initVarsControl.drawTable();
                        // set no content block visible
                        DragControl.hideBoxes();
                        document.getElementById("contentOfNoContentBox").hidden = false;
                    } catch (err) {
                        // err
                    }
                });
            }
        });
    }
}
