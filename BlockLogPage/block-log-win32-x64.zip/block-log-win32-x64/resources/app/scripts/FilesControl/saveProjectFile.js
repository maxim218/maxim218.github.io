"use strict";

import global from "./../GlobalObjStore/global";

function getId(idString) {
    return document.getElementById(idString);
}

export default function saveProjectFile() {
    const fs = require('fs');
    const {dialog} = require('electron').remote;

    getId("projectWorkBtnSave").onclick = function () {
        dialog.showSaveDialog((fileName) => {
            console.log(fileName);
            if(fileName !== undefined) {
                const obj = {
                    programContent: global().programContent,
                    variablesContent: global().variablesContent,
                };
                const contentFile = JSON.stringify(obj);
                fs.writeFile(fileName, contentFile, function(err) {
                    if(!err) {
                        console.log("--- Save file OK ---");
                    }
                });
            }
        });
    }
}
