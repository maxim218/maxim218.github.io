"use strict";

const OBJ = {
    programContent: [],
    variablesContent: {},
};

export default function global() {
    return OBJ;
}
