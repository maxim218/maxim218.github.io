"use strict";

function getId(idString) {
    return document.getElementById(idString);
}

export default function hideShowConsoleEvent() {
    getId("hideShowConsoleBtn").onclick = function() {
        getId('consoleBox').hidden = !getId('consoleBox').hidden;
    };
}
