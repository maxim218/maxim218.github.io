"use strict";

export default function jqueryManager() {
    const $ = require("jquery");
    const waitTime = 300;

    $("#argumentsBtn").click(function() {
        $("#argumentsBoxContent").slideToggle(waitTime);
    });

    $("#blokiBtn").click(function() {
        $("#blocksBtnBox").slideToggle(waitTime);
    });

    $("#sodergimBtn").click(function () {
        $("#sodergimoeBox").slideToggle(waitTime);
    });
}
