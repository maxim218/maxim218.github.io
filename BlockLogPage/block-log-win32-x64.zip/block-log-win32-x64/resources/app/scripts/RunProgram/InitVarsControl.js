"use strict";

import global from "./../GlobalObjStore/global";

const START_VALUE = 0;

function getId(idString) {
    return document.getElementById(idString);
}

export default class InitVarsControl {
    initFieldsAndButtons() {
        this.nameField = getId("addArgLabelName");
        this.valueField = getId("addArgLabelValue");
        this.addBtn = getId("argAddBtn");
        this.clearBtn = getId("argClearBtn");
        this.argsBoxWithTable = getId("argsBoxWithTable");
    }

    drawTable() {
        this.argsBoxWithTable.innerHTML = "";
        let contentString = "";
        contentString += "<table><tbody><tr><td><b>Имя</b></td><td><b>Значение</b></td></tr>";
        for(let key in global().variablesContent) {
            const value = global().variablesContent[key.toString()];
            const resultName = key.toString();
            const resultValue = parseInt(value);
            contentString += `<tr><td>${resultName}</td><td>${resultValue}</td></tr>`;
        }
        this.argsBoxWithTable.innerHTML = "";
        contentString += "</tbody></table>";
        this.argsBoxWithTable.innerHTML = contentString.toString();
    }

    addEventToClearBtn() {
        this.clearBtn.onclick = () => {
            this.clearTextFields();
            global().variablesContent = {};
            // draw table
            this.drawTable();
        };
    }

    clearTextFields() {
        this.nameField.value = "";
        this.valueField.value = "";
    }

    addEventToAddingBtn() {
        this.addBtn.onclick = () => {
            if(this.nameField.value && this.valueField.value) {
                let nameContent = this.nameField.value;
                let valueContent = parseInt(this.valueField.value);
                if(valueContent === null || valueContent === undefined || isNaN(valueContent) === true) {
                    valueContent = START_VALUE;
                }
                this.clearTextFields();
                global().variablesContent[nameContent] = parseInt(valueContent);
                // draw table
                this.drawTable();
            }
        }
    }

    constructor() {
        console.log("Create InitVarsControl");
        // init DOM elements
        this.initFieldsAndButtons();
        // add event to add btn
        this.addEventToAddingBtn();
        // add event to clear btn
        this.addEventToClearBtn();
        // draw table
        this.drawTable();
    }
}
