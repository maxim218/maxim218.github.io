"use strict";

import global from "../GlobalObjStore/global";
import DragControl from "../DragManage/DragControl";

const START_VALUE = 0;
const CODE_OK = "x11111x11111x111xOKxCODEx11xMaxim";
const CODE_ERROR = "x22222x222x2222xERRORxCODEx22xMaxim";

let count = 0;

export default class ProgramRunner {
    constructor() {
        count += 1;
        console.log("Create ProgramRunner (number: " + count + ")");
    }

    writeContent(content) {
        this.printIngBox.value += (content + "  ");
        console.log("Write: " + content);
    }

    static getContentArray() {
        const contentArrayGlobal = global().programContent;
        const contentArrayString = JSON.stringify(contentArrayGlobal);
        return JSON.parse(contentArrayString.toString());
    }

    findStartBlock() {
        const arr = this.arr;
        for(let i = 0; i < arr.length; i++) {
            const b = arr[i];
            if(b.startBloc) {
                return b;
            }
        }
        return undefined;
    }

    clearConsole() {
        this.printIngBox = document.getElementById('consoleBoxContentValuesBox');
        this.printIngBox.value = "";
    }

    static hideConsole() {
        document.getElementById('consoleBox').hidden = false;
    }

    initCopyVariablesObject() {
        this.variables = {};
        const objString = JSON.stringify(global().variablesContent);
        this.variables = JSON.parse(objString.toString());
    }

    runProgram() {
        this.arr = ProgramRunner.getContentArray();
        this.nowBlock = this.findStartBlock();
        // init variables
        this.variables = {};
        // init variables started
        this.initCopyVariablesObject();
        // clear console
        this.clearConsole();
        // hide console
        ProgramRunner.hideConsole();
        // start
        this.startWorking();
    }

    static getHitBlockTochka(xxx, yyy, b) {
        return DragControl.inBox(b.x, b.y, b.w, b.h, xxx, yyy) === true;
    }

    static getHitBlockPoint(xxx, yyy, b) {
        if(ProgramRunner.getHitBlockTochka(xxx, yyy, b) === true) return true;
        if(ProgramRunner.getHitBlockTochka(xxx - 10, yyy - 10, b) === true) return true;
        if(ProgramRunner.getHitBlockTochka(xxx + 10, yyy + 10, b) === true) return true;
        if(ProgramRunner.getHitBlockTochka(xxx + 10, yyy - 10, b) === true) return true;
        if(ProgramRunner.getHitBlockTochka(xxx - 10, yyy + 10, b) === true) return true;
        return null;
    }

    workWithContentOfBlock(nowBlock) {
        if(nowBlock.readingDataBox === true) {
            return this.workReadBlock(nowBlock);
        } else if(nowBlock.basic === true) {
            return this.workBasic(nowBlock);
        } else if(nowBlock.printingVars === true) {
            return this.workPrintingBlock(nowBlock);
        } else if(nowBlock.connection === true) {
            return true;
        } else if(nowBlock.vetvlenie === true) {
            return this.workWithIfElseBlock(nowBlock);
        }
        return true;
    }

    controlVariable(param) {
        // is it simple number
        const num = parseInt(param);
        if(isNaN(num) === false) {
            // it is simple number
            return num;
        }

        // it is not number

        // if it is simple variable
        if(param.indexOf("_") === -1) {
            if(this.variables[param] === undefined) {
                this.variables[param] = START_VALUE;
            }
            return this.variables[param];
        }

        // if it is element of array
        const mass = param.split("_");
        const arrayName = mass[0];
        const arrayElem = mass[1];

        if(this.variables[arrayName] === undefined) {
            this.variables[arrayName] = [];
        }

        const n = parseInt(arrayElem);
        if(isNaN(n) === false) {
            // it is number
            return this.variables[arrayName][n];
        } else {
            const k = this.variables[arrayElem];
            return this.variables[arrayName][k];
        }
    }

    controlVariableFinish(param) {
        const resultVar = this.controlVariable(param);
        const resultInt = parseInt(resultVar);
        if(resultInt === null || resultInt === undefined || isNaN(resultInt) === true) {
            return START_VALUE;
        } else {
            return parseInt(resultInt.toString());
        }
    }

    workPrintingBlock(nowBlock) {
        if(nowBlock.action) {
            const action = nowBlock.action;
            const info = this.controlVariableFinish(action.info);
            this.writeContent(info);
            return true;
        }
    }

    workWithIfElseBlock(nowBlock) {
        if(nowBlock.action) {
            const action = nowBlock.action;

            let a = this.controlVariableFinish(action.firstElement);
            let b = this.controlVariableFinish(action.secondElement);
            const act = action.act;

            a = parseInt(a);
            b = parseInt(b);

            let resultFlag = false;

            if(act === "==") {
                if(a === b) {
                    resultFlag = true;
                }
            }

            if(act === "<") {
                if(a < b) {
                    resultFlag = true;
                }
            }

            if(act === "<=") {
                if(a <= b) {
                    resultFlag = true;
                }
            }

            if(resultFlag === true) {
                return CODE_OK;
            } else {
                return CODE_ERROR;
            }
        }
    }

    workReadBlock(nowBlock) {
        if(nowBlock.action) {
            const action = nowBlock.action;
            const read = action.read + "";
            const key = read.toString();

            let value = parseInt(this.inpMass[0]);

            try {
                this.inpMass.splice(0, 1);
            } catch (err) {
                // err
            }

            if(value === null || value === undefined || isNaN(value) === true) {
                value = parseInt(START_VALUE);
            }

            this.variables[key] = parseInt(value);
        }
    }

    workBasic(nowBlock) {
        if(nowBlock.action) {
            const action = nowBlock.action;
            const res = this.controlVariableFinish(action.tRes);
            const a = this.controlVariableFinish(action.tA);
            const b = this.controlVariableFinish(action.tB);
            const toDo = action.tAction;
            let answer = START_VALUE;
            switch (toDo) {
                case "+": answer = a + b; break;
                case "-": answer = a - b; break;
                case "*": answer = a * b; break;
                case "/": answer = a / b; break;
                case "%": answer = a % b; break;
            }
            answer = parseInt(answer.toString());
            const name = action.tRes;
            if(name.indexOf("_") === -1) {
                this.variables[name] = answer;
            } else {
                const mass = name.split("_");
                const arrayName = mass[0];
                const arrayElem = mass[1];

                const n = parseInt(arrayElem);
                if(isNaN(n) === false) {
                    // it is number
                    this.variables[arrayName][n] = answer;
                } else {
                    const k = this.variables[arrayElem];
                    this.variables[arrayName][k] = answer;
                }
            }
        }
    }

    getVariablesFromInputConsole() {
        const consoleField = document.getElementById("consoleBoxContentValuesBoxForInputData");
        const consoleText = consoleField.value + "";
        const arr = consoleText.split(" ");
        this.inpMass = [];
        for(let i = 0; i < arr.length; i++) {
            const x = parseInt(arr[i]);
            if(x === null || x === undefined || isNaN(x) === true) {
                this.inpMass.push(parseInt(START_VALUE));
            } else {
                this.inpMass.push(parseInt(x));
            }
        }
        console.log("Input mass: " + this.inpMass);
    }

    startWorking() {
        this.printIngBox.value = "";
        let nowBlock = this.nowBlock;
        let arr = this.arr;

        this.getVariablesFromInputConsole();

        while(true) {
            const workOutput = this.workWithContentOfBlock(nowBlock);
            if(workOutput !== CODE_OK && workOutput !== CODE_ERROR) {
                // not if else block
                let found = false;
                for (let i = 0; i < arr.length; i++) {
                    const b = arr[i];
                    if (ProgramRunner.getHitBlockPoint(nowBlock.strFinishX, nowBlock.strFinishY, b)) {
                        nowBlock = b;
                        found = true;
                        break;
                    }
                }
                if (found === false) {
                    break;
                }
            } else {
                // it is IfElse block
                let found = false;
                for (let i = 0; i < arr.length; i++) {
                    const b = arr[i];
                    if(workOutput === CODE_OK) {
                        if (ProgramRunner.getHitBlockPoint(nowBlock.strFinishX, nowBlock.strFinishY, b)) {
                            nowBlock = b;
                            found = true;
                            break;
                        }
                    } else {
                        if (ProgramRunner.getHitBlockPoint(nowBlock.strFinishXsecond, nowBlock.strFinishYsecond, b)) {
                            nowBlock = b;
                            found = true;
                            break;
                        }
                    }
                }
                if (found === false) {
                    break;
                }
            }
        }

        this.printVariablesObject();
    }

    printVariablesObject() {
        console.log("Variables: ");
        console.log(this.variables);
    }
}
