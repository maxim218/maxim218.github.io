"use strict";

import global from "../GlobalObjStore/global";
import ProgramRunner from "./ProgramRunner";

function getId(idString) {
    return document.getElementById(idString);
}

export default function runProgramEvent() {
    getId("runProgramBtn").onclick = () => {
        global().programRunner = null;
        global().programRunner = new ProgramRunner();
        global().programRunner.runProgram();
        global().programRunner = null;
    };
}

