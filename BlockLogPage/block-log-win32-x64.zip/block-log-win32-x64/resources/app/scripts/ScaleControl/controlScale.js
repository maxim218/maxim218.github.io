"use strict";

function getId(idString) {
    return document.getElementById(idString);
}

export default function controlScale() {
    const {webFrame} = require('electron');

    let zoomValue = webFrame.getZoomFactor();

    const deltaZoom = 0.2;
    const maxZoom = 1.3;
    const minZoom = 0.7;

    function setWindowZoom(value) {
        webFrame.setZoomFactor(value);
    }

    function plusZoom() {
        if(zoomValue < maxZoom) {
            zoomValue += deltaZoom;
            setWindowZoom(zoomValue);
        }
    }

    function minusZoom() {
        if(zoomValue > minZoom) {
            zoomValue -= deltaZoom;
            setWindowZoom(zoomValue);
        }
    }

    getId("plusZoomBtn").onclick = function() {
        plusZoom();
    };

    getId("minusZoomBtn").onclick = function() {
        minusZoom();
    };
}
