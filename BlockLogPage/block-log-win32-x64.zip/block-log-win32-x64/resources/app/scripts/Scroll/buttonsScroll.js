"use strict";

import global from "../GlobalObjStore/global";

function getId(idString) {
    return document.getElementById(idString);
}

const deltaValue = -100;

export default function buttonsScroll() {
    getId("leftBtn").onclick = function () {
        global().canvasManager.dx += deltaValue;
        global().canvasManager.printAllBoxes();
    };

    getId("rightBtn").onclick = function () {
        global().canvasManager.dx -= deltaValue;
        global().canvasManager.printAllBoxes();
    };

    getId("topBtn").onclick = function () {
        global().canvasManager.dy += deltaValue;
        global().canvasManager.printAllBoxes();
    };

    getId("bottomBtn").onclick = function () {
        global().canvasManager.dy -= deltaValue;
        global().canvasManager.printAllBoxes();
    };
}
