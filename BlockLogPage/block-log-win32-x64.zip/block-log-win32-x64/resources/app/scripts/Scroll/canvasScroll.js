"use strict";

import global from "../GlobalObjStore/global";

export default function canvasScroll() {
    const t = global().canvasManager;
    // control wheel
    t.can.onmousewheel = (event) => {
        const speedMoving = 30;
        const deltaY = parseInt(event.deltaY);
        if(deltaY > 0) {
            t.dy += speedMoving;
        } else {
            t.dy -= speedMoving;
        }
        t.printAllBoxes();
    };
}
