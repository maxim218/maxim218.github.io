"use strict";

function getId(idString) {
    return document.getElementById(idString);
}

export default function leftMenuScroll() {
    const leftMenu = getId("leftMenu");
    const leftContentMainBox = getId("leftContentMainBox");
    let boxPosition = 0;
    leftMenu.onmousewheel = (event) => {
        const speedMoving = 15;
        const deltaY = parseInt(event.deltaY);
        if(deltaY > 0) {
            boxPosition += speedMoving;
        } else {
            boxPosition -= speedMoving;
        }
        leftContentMainBox.style.marginTop = boxPosition + "px";
    };
}
