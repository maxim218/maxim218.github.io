"use strict";

import CanvasManager from "./CanvasControl/CanvasManager";
import global from "./GlobalObjStore/global";
import DragControl from "./DragManage/DragControl";
import PropsManager from "./BlocksPropsControl/PropsManager";
import leftMenuScroll from "./Scroll/leftMenuScroll";
import canvasScroll from "./Scroll/canvasScroll";
import buttonsScroll from "./Scroll/buttonsScroll";
import creatingIfElseBlock from "./CreatingBlocks/creatingIfElseBlock";
import creatingConnectBlock from "./CreatingBlocks/creatingConnectBlock";
import creatingPrintingBlock from "./CreatingBlocks/creatingPrintingBlock";
import creatingBasicBlock from "./CreatingBlocks/creatingBasicBlock";
import createStartB from "./CreatingBlocks/createStartB";
import connectBtnControl from "./BlockStrConnect/connectBtnControl";
import hideShowConsoleEvent from "./HideShowConsole/hideShowConsoleEvent";
import runProgramEvent from "./RunProgram/runProgramEvent";
import jqueryManager from "./JqLibScripts/jqueryManager";
import InitVarsControl from "./RunProgram/InitVarsControl";
import controlScale from "./ScaleControl/controlScale";
import saveProjectFile from "./FilesControl/saveProjectFile";
import loadProjectFile from "./FilesControl/loadProjectFile";
import createReadBlock from "./CreatingBlocks/createReadBlock";

window.onload = function() {
    // main objects creating
    global().canvasManager = new CanvasManager();
    global().dragControl = new DragControl();
    global().propsManager = new PropsManager();
    global().initVarsControl = new InitVarsControl();

    // control scroll events
    leftMenuScroll();
    canvasScroll();
    buttonsScroll();

    // creating boxes events
    creatingIfElseBlock();
    creatingConnectBlock();
    creatingPrintingBlock();
    creatingBasicBlock();
    createReadBlock();

    // create once starting box
    createStartB();

    // add event of connecting block and str while moving
    connectBtnControl();

    // add hide and show console event on btn
    hideShowConsoleEvent();

    // add run program btn event
    runProgramEvent();

    // manage jquery
    jqueryManager();

    // scale of window
    controlScale();

    // saving files control
    saveProjectFile();

    // loading files control
    loadProjectFile();
};

